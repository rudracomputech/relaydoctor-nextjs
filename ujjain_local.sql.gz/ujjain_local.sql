-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: May 18, 2026 at 02:42 PM
-- Server version: 8.0.44
-- PHP Version: 8.3.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ujjain_local`
--

-- --------------------------------------------------------

--
-- Table structure for table `availability`
--

CREATE TABLE `availability` (
  `id` bigint UNSIGNED NOT NULL,
  `module` enum('hotel','cab','food','other') DEFAULT NULL,
  `entity_id` bigint UNSIGNED DEFAULT NULL,
  `available_date` date DEFAULT NULL,
  `available_quantity` int DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` bigint UNSIGNED NOT NULL,
  `module` enum('hotel','cab','food','other') NOT NULL,
  `entity_id` bigint UNSIGNED NOT NULL,
  `vendor_id` bigint UNSIGNED NOT NULL,
  `customer_id` bigint UNSIGNED NOT NULL,
  `booking_date` datetime DEFAULT NULL,
  `check_in` datetime DEFAULT NULL,
  `check_out` datetime DEFAULT NULL,
  `guests` int DEFAULT '1',
  `total_amount` decimal(10,2) DEFAULT NULL,
  `payment_status` enum('pending','paid','failed') DEFAULT 'pending',
  `booking_status` enum('pending','confirmed','completed','cancelled') DEFAULT 'pending',
  `special_request` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cabs`
--

CREATE TABLE `cabs` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `vehicle_type` varchar(100) DEFAULT NULL,
  `seats` int DEFAULT NULL,
  `price_per_km` decimal(10,2) DEFAULT NULL,
  `driver_name` varchar(100) DEFAULT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `custom_fields`
--

CREATE TABLE `custom_fields` (
  `id` bigint UNSIGNED NOT NULL,
  `module` enum('hotel','cab','food','other') NOT NULL,
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `label` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `type` enum('text','textarea','number','select','checkbox','radio','date','time','email','url') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `options` json DEFAULT NULL,
  `is_required` tinyint(1) DEFAULT '0',
  `user_id` bigint NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `foods`
--

CREATE TABLE `foods` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `cuisine_type` varchar(100) DEFAULT NULL,
  `pure_veg` tinyint(1) DEFAULT '0',
  `opening_time` time DEFAULT NULL,
  `closing_time` time DEFAULT NULL,
  `address` text,
  `contact_number` varchar(20) DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hotels`
--

CREATE TABLE `hotels` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `description` longtext,
  `location` text NOT NULL,
  `distance_from_mahakal` varchar(55) NOT NULL,
  `total_rooms` int DEFAULT NULL,
  `person_per_room` int DEFAULT NULL,
  `room_size` varchar(50) DEFAULT NULL,
  `address` text,
  `city` varchar(100) DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `whats_app_number` varchar(55) NOT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `hotels`
--

INSERT INTO `hotels` (`id`, `user_id`, `title`, `slug`, `description`, `location`, `distance_from_mahakal`, `total_rooms`, `person_per_room`, `room_size`, `address`, `city`, `latitude`, `longitude`, `contact_person`, `contact_number`, `whats_app_number`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 'Travinities Premier', NULL, '<p>Comfortable&nbsp;Accommodations:&nbsp;Travinities&nbsp;Premier&nbsp;in&nbsp;Ujjain&nbsp;offers&nbsp;family&nbsp;rooms&nbsp;with&nbsp;air-conditioning,&nbsp;private&nbsp;bathrooms,&nbsp;and&nbsp;free&nbsp;WiFi.&nbsp;Each&nbsp;room&nbsp;includes&nbsp;a&nbsp;TV,&nbsp;electric&nbsp;kettle,&nbsp;and&nbsp;wardrobe,&nbsp;ensuring&nbsp;a&nbsp;pleasant&nbsp;stay.&nbsp;Convenient&nbsp;Facilities:&nbsp;Guests&nbsp;can&nbsp;enjoy&nbsp;a&nbsp;terrace,&nbsp;private&nbsp;check-in&nbsp;and&nbsp;check-out&nbsp;services,&nbsp;a&nbsp;lift,&nbsp;and&nbsp;a&nbsp;24-hour&nbsp;front&nbsp;desk.&nbsp;Additional&nbsp;amenities&nbsp;include&nbsp;bicycle&nbsp;parking,&nbsp;express&nbsp;check-in&nbsp;and&nbsp;check-out,&nbsp;room&nbsp;service,&nbsp;and&nbsp;a&nbsp;tour&nbsp;desk.&nbsp;Prime&nbsp;Location:&nbsp;Located&nbsp;5&nbsp;km&nbsp;from&nbsp;Mahakaleshwar&nbsp;Jyotirlinga,&nbsp;4&nbsp;km&nbsp;from&nbsp;Ujjain&nbsp;Junction&nbsp;Station,&nbsp;and&nbsp;6&nbsp;km&nbsp;from&nbsp;Ujjain&nbsp;Kumbh&nbsp;Mela.&nbsp;Devi&nbsp;Ahilya&nbsp;Bai&nbsp;Holkar&nbsp;Airport&nbsp;is&nbsp;54&nbsp;km&nbsp;away.</p>', 'Mahakal Vanijya Kendra B-7/2 M.I.G. Mahakal Vanijya Kendra Ujjain, 456010 Ujjain, India', '5', NULL, 100, '1500', NULL, NULL, NULL, NULL, 'Raj kumar', '1234567890', '1234567890', 'pending', '2026-05-12 14:33:43', '2026-05-16 16:00:47', NULL),
(2, 1, 'Siddhivinayak Home Stay', NULL, '<p>Central&nbsp;Location&nbsp;Our&nbsp;cozy&nbsp;homestay&nbsp;is&nbsp;located&nbsp;in&nbsp;the&nbsp;central&nbsp;part&nbsp;of&nbsp;Ujjain,&nbsp;offering&nbsp;excellent&nbsp;connectivity&nbsp;to&nbsp;all&nbsp;major&nbsp;attractions&nbsp;and&nbsp;basic&nbsp;facilities,&nbsp;everything&nbsp;is&nbsp;easily&nbsp;accessible&nbsp;from&nbsp;our&nbsp;location.&nbsp;Nearby&nbsp;Attractions&nbsp;•&nbsp;<strong>Mahakaleshwar</strong>&nbsp;Temple&nbsp;–&nbsp;1&nbsp;km&nbsp;•&nbsp;Ram&nbsp;Ghat&nbsp;(Shipra&nbsp;River)&nbsp;–&nbsp;1.5&nbsp;km&nbsp;•&nbsp;Harsiddhi&nbsp;Temple&nbsp;–&nbsp;1.3&nbsp;km&nbsp;•&nbsp;Ujjain&nbsp;Railway&nbsp;Station&nbsp;–&nbsp;1.5&nbsp;km&nbsp;•&nbsp;Bus&nbsp;Stand&nbsp;–&nbsp;1&nbsp;km</p>', 'Siddhi Vinayak Home Stay in Vivekanand Colony, Ujjain', '2', NULL, 1500, '1500', NULL, NULL, NULL, NULL, 'Mamta', '1234567890', '1234567890', 'pending', '2026-05-12 18:35:08', '2026-05-16 16:54:30', NULL),
(3, 1, 'test', NULL, 'faf dsfas f', 'fd afdsaf asdf', '2', NULL, 46, '1500', NULL, NULL, NULL, NULL, 'Raj kumar', '1234567890', '1234567890', 'pending', '2026-05-13 17:48:28', '2026-05-13 17:49:29', '2026-05-13 17:49:29'),
(4, 1, 'ffsafsdasfsd ', NULL, 'vva. aga gggggg', 'bbbnn yyyy', '1', NULL, 2, '1500', NULL, NULL, NULL, NULL, 'Raj kumar', '1234567890', '1234567890', 'pending', '2026-05-13 17:58:07', '2026-05-13 17:58:36', '2026-05-13 17:58:36');

-- --------------------------------------------------------

--
-- Table structure for table `hotels_guest_faq`
--

CREATE TABLE `hotels_guest_faq` (
  `id` bigint NOT NULL,
  `hotel_id` bigint UNSIGNED NOT NULL,
  `question` int NOT NULL,
  `answer` int NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hotel_room_pricing`
--

CREATE TABLE `hotel_room_pricing` (
  `id` bigint UNSIGNED NOT NULL,
  `hotel_id` bigint UNSIGNED NOT NULL,
  `room_count` int NOT NULL,
  `days_count` int NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `hotel_room_pricing`
--

INSERT INTO `hotel_room_pricing` (`id`, `hotel_id`, `room_count`, `days_count`, `price`, `created_at`, `updated_at`) VALUES
(50, 1, 1, 1, 2000.00, '2026-05-17 20:19:50', '2026-05-17 20:19:50'),
(51, 1, 1, 2, 3000.00, '2026-05-17 20:19:50', '2026-05-17 20:19:50'),
(52, 2, 1, 1, 1000.00, '2026-05-17 20:50:06', '2026-05-17 20:50:06'),
(53, 2, 1, 2, 1500.00, '2026-05-17 20:50:06', '2026-05-17 20:50:06'),
(54, 2, 2, 2, 2000.00, '2026-05-17 20:50:06', '2026-05-17 20:50:06');

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

CREATE TABLE `media` (
  `id` bigint NOT NULL,
  `module` enum('hotel','cab','food','other') DEFAULT NULL,
  `entity_id` bigint UNSIGNED DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL,
  `type` enum('image','video','document') DEFAULT 'image',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `is_main` tinyint(1) DEFAULT '0',
  `file_size` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `media`
--

INSERT INTO `media` (`id`, `module`, `entity_id`, `file`, `type`, `created_at`, `updated_at`, `deleted_at`, `is_main`, `file_size`) VALUES
(78, 'hotel', 1, '/uploads/1779049190068-rf_hotel1.jpg', 'image', '2026-05-17 20:19:50', '2026-05-17 20:19:50', NULL, 1, 207606),
(79, 'hotel', 1, '/uploads/1779049190073-rf_hotel5.jpg', 'image', '2026-05-17 20:19:50', '2026-05-17 20:19:50', NULL, 0, 262022),
(80, 'hotel', 1, '/uploads/1779049190079-rf_hotel4.jpg', 'image', '2026-05-17 20:19:50', '2026-05-17 20:19:50', NULL, 0, 113050),
(81, 'hotel', 1, '/uploads/1779049190091-rf_hotel2.jpg', 'image', '2026-05-17 20:19:50', '2026-05-17 20:19:50', NULL, 0, 257500),
(82, 'hotel', 2, '/uploads/1779051006146-rf_hotel5.jpg', 'image', '2026-05-17 20:50:06', '2026-05-17 20:50:06', NULL, 1, 262022),
(83, 'hotel', 2, '/uploads/1779051006153-rf_hotel4.jpg', 'image', '2026-05-17 20:50:06', '2026-05-17 20:50:06', NULL, 0, 113050),
(84, 'hotel', 2, '/uploads/1779051006158-rf_hotel3.jpg', 'image', '2026-05-17 20:50:06', '2026-05-17 20:50:06', NULL, 0, 35818),
(85, 'hotel', 2, '/uploads/1779051006173-rf_hotel2.jpg', 'image', '2026-05-17 20:50:06', '2026-05-17 20:50:06', NULL, 0, 257500),
(86, 'hotel', 2, '/uploads/1779051006178-rf_hotel1.jpg', 'image', '2026-05-17 20:50:06', '2026-05-17 20:50:06', NULL, 0, 207606);

-- --------------------------------------------------------

--
-- Table structure for table `myfields`
--

CREATE TABLE `myfields` (
  `id` bigint UNSIGNED NOT NULL,
  `module` enum('hotels','cabs','foods','others') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `label` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `note` varchar(255) DEFAULT NULL,
  `type` enum('text','textarea','number','select','checkbox','radio','date','time','email','url','hidden','multiselect','room_pricing') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `is_required` tinyint(1) DEFAULT '0',
  `is_system` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `user_id` bigint NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `sort_order` int UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `myfields`
--

INSERT INTO `myfields` (`id`, `module`, `name`, `label`, `note`, `type`, `is_required`, `is_system`, `status`, `user_id`, `created_at`, `updated_at`, `deleted_at`, `sort_order`) VALUES
(3, 'hotels', 'type', 'Type', '', 'multiselect', 1, 1, 1, 1, '2026-05-15 18:54:07', '2026-05-16 09:41:22', NULL, 2),
(4, 'hotels', 'room_type', 'Room Type', '', 'multiselect', 0, 0, 1, 1, '2026-05-15 18:57:59', '2026-05-16 09:36:42', NULL, 40),
(5, 'hotels', 'bed_type', 'Bed Type', '', 'multiselect', 0, 0, 1, 1, '2026-05-16 08:13:45', '2026-05-16 10:42:58', NULL, 50),
(6, 'hotels', 'amenities', 'Amenities', '', 'multiselect', 0, 0, 1, 1, '2026-05-16 09:23:24', '2026-05-16 09:36:55', NULL, 60),
(7, 'hotels', 'facilities', 'Facilities', '', 'multiselect', 0, 0, 1, 1, '2026-05-16 09:24:22', '2026-05-16 10:41:49', NULL, 70);

-- --------------------------------------------------------

--
-- Table structure for table `myfields_options`
--

CREATE TABLE `myfields_options` (
  `id` bigint UNSIGNED NOT NULL,
  `value` varchar(55) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `label` varchar(155) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `user_id` bigint NOT NULL,
  `myfield_id` bigint UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `myfields_options`
--

INSERT INTO `myfields_options` (`id`, `value`, `label`, `user_id`, `myfield_id`, `created_at`) VALUES
(1, 'hotel', 'Hotel', 1, 3, '2026-05-16 09:08:28'),
(2, 'homestay', 'Homestay', 1, 3, '2026-05-16 09:08:28'),
(3, 'dharmshala', 'Dharmshala', 1, 3, '2026-05-16 09:08:28'),
(4, 'delux', 'Delux', 1, 4, '2026-05-16 09:09:35'),
(5, 'semi-delux', 'Semi-Delux', 1, 4, '2026-05-16 09:09:35'),
(6, 'single', 'Single', 1, 5, '2026-05-16 09:10:09'),
(7, 'double', 'Double', 1, 5, '2026-05-16 09:10:09'),
(8, 'ac', 'AC', 1, 6, '2026-05-16 09:23:24'),
(9, 'wifi', 'WIFI', 1, 6, '2026-05-16 09:23:24'),
(10, 'washing-machine', 'Washing Machine', 1, 6, '2026-05-16 09:23:24'),
(11, 'parking', 'Parking', 1, 7, '2026-05-16 09:24:22'),
(12, 'pool', 'Pool', 1, 7, '2026-05-16 09:24:22');

-- --------------------------------------------------------

--
-- Table structure for table `myfields_values`
--

CREATE TABLE `myfields_values` (
  `id` bigint NOT NULL,
  `module` enum('hotels','cabs','foods','others') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `entity_id` bigint UNSIGNED NOT NULL,
  `myfield_id` bigint UNSIGNED NOT NULL,
  `value` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `sort_order` int UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `myfields_values`
--

INSERT INTO `myfields_values` (`id`, `module`, `entity_id`, `myfield_id`, `value`, `created_at`, `sort_order`) VALUES
(283, 'hotels', 1, 3, 'hotel', '2026-05-17 20:19:50', 0),
(284, 'hotels', 2, 3, 'hotel', '2026-05-17 20:50:06', 0),
(285, 'hotels', 2, 3, 'homestay', '2026-05-17 20:50:06', 0),
(286, 'hotels', 2, 3, 'dharmshala', '2026-05-17 20:50:06', 0);

-- --------------------------------------------------------

--
-- Table structure for table `others`
--

CREATE TABLE `others` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` longtext,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` bigint UNSIGNED NOT NULL,
  `booking_id` bigint UNSIGNED NOT NULL,
  `transaction_id` varchar(255) DEFAULT NULL,
  `amount` decimal(12,2) DEFAULT NULL,
  `payment_method` enum('razorpay','stripe','cash','upi') DEFAULT NULL,
  `status` enum('pending','success','failed','refunded') DEFAULT 'pending',
  `paid_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` int NOT NULL,
  `name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`) VALUES
(1, 'user:create'),
(2, 'user:read'),
(3, 'user:update'),
(4, 'user:update:own'),
(5, 'user:delete'),
(6, 'dashboard:view'),
(7, '*');

-- --------------------------------------------------------

--
-- Table structure for table `ratings`
--

CREATE TABLE `ratings` (
  `id` bigint UNSIGNED NOT NULL,
  `entity_type` enum('hotel','cab','food','other') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `entity_id` bigint UNSIGNED DEFAULT NULL,
  `customer_id` bigint UNSIGNED DEFAULT NULL,
  `rating` tinyint NOT NULL,
  `comment` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int NOT NULL,
  `name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`) VALUES
(1, 'admin'),
(2, 'editor'),
(3, 'viewer');

-- --------------------------------------------------------

--
-- Table structure for table `role_permissions`
--

CREATE TABLE `role_permissions` (
  `role_id` int DEFAULT NULL,
  `permission_id` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `role_permissions`
--

INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES
(1, 1),
(1, 2),
(1, 3),
(1, 4),
(1, 5),
(1, 6),
(1, 7);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `created_by`, `created_at`) VALUES
(1, 'rudracomputechs@gmail.com', '$2b$10$Vxq5tiRB.rgl.5XU.OT3WOJxsasr3t1p5HjAynwAT8Kfu.WNMVHRy', NULL, '2026-04-25 12:10:54');

-- --------------------------------------------------------

--
-- Table structure for table `user_roles`
--

CREATE TABLE `user_roles` (
  `user_id` int DEFAULT NULL,
  `role_id` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `availability`
--
ALTER TABLE `availability`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cabs`
--
ALTER TABLE `cabs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `custom_fields`
--
ALTER TABLE `custom_fields`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `foods`
--
ALTER TABLE `foods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hotels`
--
ALTER TABLE `hotels`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Indexes for table `hotels_guest_faq`
--
ALTER TABLE `hotels_guest_faq`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hotel_id` (`hotel_id`);

--
-- Indexes for table `hotel_room_pricing`
--
ALTER TABLE `hotel_room_pricing`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_hotel` (`hotel_id`);

--
-- Indexes for table `media`
--
ALTER TABLE `media`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `myfields`
--
ALTER TABLE `myfields`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_sort` (`user_id`,`sort_order`);

--
-- Indexes for table `myfields_options`
--
ALTER TABLE `myfields_options`
  ADD PRIMARY KEY (`id`),
  ADD KEY `myfields_ibfk_1` (`myfield_id`),
  ADD KEY `user_ibfk_1` (`user_id`);

--
-- Indexes for table `myfields_values`
--
ALTER TABLE `myfields_values`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_custom_value` (`module`,`entity_id`,`myfield_id`,`value`(255)) USING BTREE,
  ADD KEY `fk_myfield_id` (`myfield_id`) USING BTREE,
  ADD KEY `idx_user_sort` (`myfield_id`,`sort_order`);

--
-- Indexes for table `others`
--
ALTER TABLE `others`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `booking_id` (`booking_id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ratings`
--
ALTER TABLE `ratings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `availability`
--
ALTER TABLE `availability`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cabs`
--
ALTER TABLE `cabs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `custom_fields`
--
ALTER TABLE `custom_fields`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `foods`
--
ALTER TABLE `foods`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hotels`
--
ALTER TABLE `hotels`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `hotels_guest_faq`
--
ALTER TABLE `hotels_guest_faq`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hotel_room_pricing`
--
ALTER TABLE `hotel_room_pricing`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `media`
--
ALTER TABLE `media`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- AUTO_INCREMENT for table `myfields`
--
ALTER TABLE `myfields`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `myfields_options`
--
ALTER TABLE `myfields_options`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `myfields_values`
--
ALTER TABLE `myfields_values`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=287;

--
-- AUTO_INCREMENT for table `others`
--
ALTER TABLE `others`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `ratings`
--
ALTER TABLE `ratings`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `hotels_guest_faq`
--
ALTER TABLE `hotels_guest_faq`
  ADD CONSTRAINT `hotels_guest_faq_ibfk_1` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `hotel_room_pricing`
--
ALTER TABLE `hotel_room_pricing`
  ADD CONSTRAINT `fk_hotel_room_pricing_hotel` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `myfields_options`
--
ALTER TABLE `myfields_options`
  ADD CONSTRAINT `myfields_ibfk_1` FOREIGN KEY (`myfield_id`) REFERENCES `myfields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `myfields_values`
--
ALTER TABLE `myfields_values`
  ADD CONSTRAINT `myfields_values_ibfk_1` FOREIGN KEY (`myfield_id`) REFERENCES `myfields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
